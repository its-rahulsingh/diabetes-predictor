# import pickle
# # import sklearn
# filename = 'finalized_model.pkl'
# loaded_model = pickle.load(open(filename, 'rb'))
# result = loaded_model.predict([[1,121,78,39,74,39,0.261,28]])
# print(result)

import pandas